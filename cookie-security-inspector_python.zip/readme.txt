My app analyzes the Cookie of a Website. If it is vulnerable, it tells you for which hacker-attacks.

Music by glitchart